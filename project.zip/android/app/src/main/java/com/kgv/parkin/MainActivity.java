package com.kgv.parkin;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
