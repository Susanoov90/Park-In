// import { useEffect, useRef } from 'react';
// import { GoogleMap } from '@capacitor/google-maps';
// import { Geolocation } from '@capacitor/geolocation';

// export default function RenderMapsOnHome() {
//   const divRef = useRef<HTMLDivElement>(null);
//   const mapRef = useRef<GoogleMap | null>(null);

//   useEffect(() => {
//     (async () => {
//       await Geolocation.requestPermissions();
//       const { coords } = await Geolocation.getCurrentPosition({ enableHighAccuracy: true });
//       const center = { lat: coords.latitude, lng: coords.longitude };

//       mapRef.current = await GoogleMap.create({
//           id: 'home-map',
//           element: divRef.current!,
//           config: { center, zoom: 16 },
//           apiKey: 'AIzaSyDxdwEIjs9ZZrLJGsgiZ4K_N8wuJlukfGA'
//       });

//       await mapRef.current.addMarker({ coordinate: center, title: 'Moi' });
//     })();

//     return () => { mapRef.current?.destroy(); };
//   }, []);

//   return <div ref={divRef} style={{ height: 800, borderRadius: 12, overflow: 'hidden' }} />;
// }
